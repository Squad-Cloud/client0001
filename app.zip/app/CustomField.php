<?php

namespace App;

class CustomField extends BaseModel
{
    public $timestamps = false;
}
