<?php

namespace App;

class FrontWidget extends BaseModel
{
    protected $guarded = ['id'];
}
